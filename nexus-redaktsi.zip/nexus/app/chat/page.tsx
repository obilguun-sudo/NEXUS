'use client'
import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'

interface Source { num: number; id: string; desc: string; url: string }
interface Message {
  role: 'user' | 'ai'
  text: string
  sources?: Source[]
}

const SAMPLE_SOURCES: Source[] = [
  { num: 1, id: 'NEX-2024-007', desc: 'Оффшор шилжүүлэг · $47.3M', url: '/doc/NEX-2024-007' },
  { num: 2, id: 'NEX-2025-022', desc: 'Зөвлөлийн мөрдөн шалгалт', url: '/doc/NEX-2025-022' },
  { num: 3, id: 'NEX-2026-011', desc: 'Прокурорын хэрэг үүсгэлт', url: '/doc/NEX-2026-011' },
  { num: 4, id: 'NEX-2026-009', desc: 'Дезинформацийн кампанит ажил', url: '/doc/NEX-2026-009' },
]

const SAMPLE_ANSWER = `Манай архивд Steppe Media Holding-тай холбоотой 4 гол баримт бичиг байна.

**Санхүүгийн зөрчил.** 2024 оны 11-р сард нийт **47.3 сая ам.долларын** оффшор шилжүүлэг хийсэн нь ил болсон[1]. Үүний дараа Хэвлэл мэдээллийн зөвлөл 2025 оны 3-р сард албан ёсны мөрдөн шалгалт эхлүүлжээ[2].

**Эрүүгийн хэрэг.** 2026 оны 4-р сард авлигын хэргийн прокурор 7 удирдах ажилтны эсрэг шүүхэд хэрэг үүсгэв[3]. Нийт 1,250 хуудас нотолгооны материал болон гадаадын 4 шүүхийн харьяаллаас татан авсан баримт багтсан.

**Худал мэдээллийн кампанит ажил.** 2026 оны 3-р сард манай сонины судалгааг гутаах зорилгоор координацлагдсан дезинформацийн кампанит ажил явагдсан нь баримтлагдсан[4]. 412 данс, 87% нь координацлагдсан зан төлөв үзүүлсэн.`

interface Conv { id: string; title: string; meta: string; pinned?: boolean; group?: string }

const INITIAL_CONVS: Conv[] = [
  { id: 'c1', title: 'Steppe Media Holding судалгааны явц', meta: '2 мес · 09:14', group: 'Steppe судалгаа' },
  { id: 'c2', title: '«Медиа боловсрол 2026» эх сурвалжуудын зөрчил', meta: '4 мес · 08:41' },
  { id: 'c3', title: 'Худал мэдээллийн attribution', meta: '2 мес · 07:55', group: 'Steppe судалгаа' },
  { id: 'c4', title: 'Эх сурвалж хамгаалал / кибер', meta: '6 мес · өчигдөр' },
  { id: 'c5', title: 'NEX-2025-048 дэлгэрэнгүй шинжилгээ', meta: '3 мес · өчигдөр', pinned: true },
  { id: 'c6', title: '«Алтан Үсэг» оффшор гүйлгээ', meta: '8 мес · 2 өдрийн өмнө', group: 'Steppe судалгаа' },
  { id: 'c7', title: 'Шүүхийн мэдэгдлүүдийн тойм', meta: '5 мес · 3 өдрийн өмнө', pinned: true },
]

const PROMPTS = [
  { icon: 'ti-building', text: 'Steppe Media Holding судалгааны явц ямар байна?' },
  { icon: 'ti-chart-bar', text: '«Медиа боловсрол 2026» хөтөлбөрийн зөрчлийг харьцуулна уу' },
  { icon: 'ti-bug', text: 'Худал мэдээллийн кампанит ажлын attribution хаана хүрсэн бэ?' },
  { icon: 'ti-shield', text: 'Эх сурвалж хамгаалал болон кибер аюулгүй байдлын мэдээ' },
]

function renderAnswer(text: string, sources: Source[]) {
  const sourceMap: Record<string, Source> = {}
  sources.forEach(s => { sourceMap[String(s.num)] = s })

  const parts = text.split(/(\*\*[^*]+\*\*|\[\d+\])/g)
  return parts.map((part, i) => {
    const boldMatch = part.match(/^\*\*([^*]+)\*\*$/)
    if (boldMatch) return <strong key={i}>{boldMatch[1]}</strong>
    const refMatch = part.match(/^\[(\d+)\]$/)
    if (refMatch) {
      const src = sourceMap[refMatch[1]]
      if (src) return (
        <a key={i} href={src.url} className="inline-cite" title={src.desc}>
          <i className="ti ti-file-text" />
          {src.id}
        </a>
      )
    }
    return part
  })
}

export default function ChatPage() {
  const [sbOpen, setSbOpen] = useState(true)
  const [convs, setConvs] = useState<Conv[]>(INITIAL_CONVS)
  const [activeId, setActiveId] = useState<string | null>('c2')
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [groupOpen, setGroupOpen] = useState(true)
  const taRef = useRef<HTMLTextAreaElement>(null)
  const chatRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight
  }, [messages])

  const autoResize = () => {
    const ta = taRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 100) + 'px'
  }

  const send = (text?: string) => {
    const val = (text ?? input).trim()
    if (!val) return
    const isFirst = messages.length === 0
    const userMsg: Message = { role: 'user', text: val }
    const aiMsg: Message = {
      role: 'ai',
      text: isFirst && val.toLowerCase().includes('steppe') ? SAMPLE_ANSWER : `«${val}» гэсэн асуултын хариуг редакцийн мэдээллийн сангаас хайж байна. Одоогоор mock горимд ажиллаж байна — бодит LLM холболт хийгдэх үед дэлгэрэнгүй хариу гарна.`,
      sources: isFirst && val.toLowerCase().includes('steppe') ? SAMPLE_SOURCES : undefined,
    }
    setMessages(prev => [...prev, userMsg, aiMsg])
    setInput('')
    if (taRef.current) taRef.current.style.height = 'auto'
    if (!activeId) { const id = 'new-' + Date.now(); setActiveId(id) }
  }

  const togglePin = (id: string) => {
    setConvs(prev => prev.map(c => c.id === id ? { ...c, pinned: !c.pinned } : c))
  }

  const deleteConv = (id: string) => {
    setConvs(prev => prev.filter(c => c.id !== id))
    if (activeId === id) { setActiveId(null); setMessages([]) }
  }

  const newChat = () => { setActiveId(null); setMessages([]) }

  const pinned = convs.filter(c => c.pinned)
  const grouped = convs.filter(c => c.group === 'Steppe судалгаа' && !c.pinned)
  const recent = convs.filter(c => !c.pinned && !c.group)

  const ConvItem = ({ c }: { c: Conv }) => (
    <div className={`conv-item ${activeId === c.id ? 'active' : ''}`} onClick={() => { setActiveId(c.id); if (messages.length === 0 && c.id === 'c1') { setMessages([{ role: 'user', text: 'Steppe Media Holding-ийн талаар манай редакцад юу байна? Товч хураангуйлаад өгнө үү.' }, { role: 'ai', text: SAMPLE_ANSWER, sources: SAMPLE_SOURCES }]) } }}>
      <div className="conv-left">
        <div className="conv-title">
          {c.pinned && <i className="ti ti-pin-filled conv-pin-icon" />}
          {c.title}
        </div>
        <div className="conv-meta">{c.meta}</div>
      </div>
      <div className="ci-actions">
        <button className="ci-btn" title={c.pinned ? 'Бэхэлгээ арилгах' : 'Бэхлэх'} onClick={e => { e.stopPropagation(); togglePin(c.id) }}>
          <i className={`ti ${c.pinned ? 'ti-pin-off' : 'ti-pin'}`} />
        </button>
        <button className="ci-btn" title="Устгах" onClick={e => { e.stopPropagation(); deleteConv(c.id) }}>
          <i className="ti ti-x" />
        </button>
      </div>
    </div>
  )

  return (
    <div className="chat-shell">
      {/* Sidebar */}
      <div className={`chat-sb ${sbOpen ? '' : 'collapsed'}`}>
        <div className="chat-sb-head">
          <div>
            <div className="chat-brand-tag">NEXUS // NEWS DESK</div>
            <div className="chat-brand-name">Редактор AI</div>
          </div>
          <button className="chat-new-btn" onClick={newChat}>
            <i className="ti ti-edit" />
            <span className="chat-new-btn-label">Шинэ чат</span>
            <span className="chat-new-btn-kbd">⌘N</span>
          </button>
        </div>

        <div className="chat-sb-body">
          {pinned.length > 0 && (
            <>
              <div className="sb-section-row"><span className="sb-sec-label">Бэхэлсэн</span></div>
              {pinned.map(c => <ConvItem key={c.id} c={c} />)}
            </>
          )}

          <div className="sb-section-row" style={{ marginTop: 4 }}>
            <span className="sb-sec-label">Бүлгүүд</span>
            <button className="sb-add-btn" title="Шинэ бүлэг"><i className="ti ti-folder-plus" /></button>
          </div>
          <div className="group-block">
            <div className="group-header" onClick={() => setGroupOpen(o => !o)}>
              <i className="ti ti-folder" />
              <span className="group-name">Steppe судалгаа</span>
              <span className="group-count">{grouped.length}</span>
              <i className="ti ti-chevron-down" style={{ fontSize: 11, color: 'var(--t3)', transform: groupOpen ? '' : 'rotate(-90deg)', transition: 'transform .15s' }} />
            </div>
            {groupOpen && (
              <div className="group-body">
                {grouped.map(c => <ConvItem key={c.id} c={c} />)}
              </div>
            )}
          </div>

          <div className="sb-section-row" style={{ marginTop: 4 }}><span className="sb-sec-label">Сүүлийн</span></div>
          {recent.map(c => <ConvItem key={c.id} c={c} />)}
        </div>

        <div className="chat-sb-foot">
          <div className="status-dot" />
          <span>nexus-mock-analyst · v0.1.0</span>
        </div>
      </div>

      {/* Main */}
      <div className="chat-main">
        <div className="chat-topbar">
          <button className="icon-btn" onClick={() => setSbOpen(o => !o)} aria-label="Sidebar нуух">
            <i className={`ti ${sbOpen ? 'ti-layout-sidebar' : 'ti-layout-sidebar-right'}`} />
          </button>
          <span className="chat-topbar-title">
            {activeId ? (convs.find(c => c.id === activeId)?.title ?? 'Шинэ чат') : 'Шинэ чат'}
          </span>
          <span className="chat-topbar-badge">MOCK · rule-based</span>
          <button className="icon-btn" aria-label="Хуваалцах"><i className="ti ti-share" /></button>
        </div>

        {/* System banner */}
        <div className="system-banner">
          <div className="system-banner-dot" />
          <span>Редакцийн мэдээллийн санд тулгуурласан хариулт. Эх ишлэлийг [NEX-...] хэлбэрээр оруулна.</span>
          <span style={{ marginLeft: 8, color: 'var(--border2)' }}>·</span>
          <span style={{ marginLeft: 8 }}>● MOCK | in-process (rule-based) | nexus-mock-analyst</span>
        </div>

        <div className="chat-area" ref={chatRef}>
          {messages.length === 0 ? (
            <div className="welcome-screen">
              <div className="welcome-eyebrow">NEXUS // NEWS DESK · Редакцийн систем</div>
              <div className="welcome-title">Редактор AI туслах</div>
              <div className="welcome-sub">Редакцийн мэдээллийн санд тулгуурласан хариулт өгнө. Эх сурвалжийг [NEX-...] хэлбэрээр дурдана.</div>
              <div className="prompt-label">Санал болгох асуултууд</div>
              <div className="prompt-list">
                {PROMPTS.map(p => (
                  <div key={p.text} className="prompt-row" onClick={() => send(p.text)}>
                    <i className={`ti ${p.icon}`} />
                    <span className="prompt-row-text">{p.text}</span>
                    <i className="ti ti-arrow-right" style={{ fontSize: 11, color: 'var(--t3)' }} />
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="messages">
              <div className="day-divider"><span>Өнөөдөр · 09:14</span></div>
              {messages.map((msg, i) => (
                msg.role === 'user' ? (
                  <div key={i} className="msg-user">
                    <div className="user-bubble">{msg.text}</div>
                  </div>
                ) : (
                  <div key={i} className="msg-ai">
                    <div className="ai-header">
                      <span className="ai-label">Редактор AI</span>
                      <span className="ai-model-tag">nexus-mock-analyst</span>
                    </div>
                    {msg.sources && (
                      <div className="sources-strip">
                        <div className="sources-label">Эх сурвалжууд</div>
                        <div className="sources-row">
                          {msg.sources.map(s => (
                            <Link key={s.id} href={s.url} className="source-card">
                              <span className="sc-num">{s.num}</span>
                              <span className="sc-id">{s.id}</span>
                              <span className="sc-desc">{s.desc}</span>
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="ai-answer">
                      {msg.text.split('\n\n').map((para, pi) => (
                        <p key={pi}>{renderAnswer(para, msg.sources ?? [])}</p>
                      ))}
                    </div>
                    <div className="msg-actions">
                      <button className="act-btn" onClick={() => navigator.clipboard?.writeText(msg.text)}><i className="ti ti-copy" /> Хуулах</button>
                      <button className="act-btn"><i className="ti ti-refresh" /> Дахин</button>
                    </div>
                  </div>
                )
              ))}
            </div>
          )}
        </div>

        <div className="composer-wrap">
          <div className="composer">
            <textarea
              ref={taRef}
              className="composer-ta"
              rows={1}
              value={input}
              onChange={e => { setInput(e.target.value); autoResize() }}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }}
              placeholder="Асуулт бичнэ үү..."
            />
            <div className="composer-bar">
              <button className="cb-action" aria-label="Файл хавсаргах"><i className="ti ti-paperclip" /></button>
              <button className="cb-action" aria-label="Баримт хайх"><i className="ti ti-file-search" /></button>
              <span className="cb-spacer" />
              <span className="cb-hint">Enter илгээх · Shift+Enter мөр</span>
              <button className="send-btn" onClick={() => send()} aria-label="Илгээх"><i className="ti ti-arrow-up" /></button>
            </div>
          </div>
          <div className="composer-foot">
            <i className="ti ti-lock" />
            <span>Зөвхөн зөвшөөрөгдсөн системийн мэдээллийн сан</span>
            <span className="cf-right">Дотоод сүлжээ · Шифрлэгдсэн</span>
          </div>
        </div>
      </div>
    </div>
  )
}
