'use client'
import { useState } from 'react'
import Link from 'next/link'

export default function AiWidget() {
  const [open, setOpen] = useState(true)
  const [val, setVal] = useState('')

  if (!open) return (
    <button onClick={() => setOpen(true)} style={{ position: 'fixed', bottom: 24, right: 24, background: 'var(--gold)', border: 'none', borderRadius: 3, padding: '8px 14px', color: '#fff', fontSize: 12, fontFamily: 'inherit', cursor: 'pointer', zIndex: 200 }}>
      AI ↗
    </button>
  )

  return (
    <div className="ai-widget">
      <div className="ai-widget-head">
        <span className="ai-widget-label">Редактор AI</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Link href="/chat" className="ai-widget-link">бүгдийг харах ↗</Link>
          <button onClick={() => setOpen(false)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--t3)', fontSize: 14 }}>×</button>
        </div>
      </div>
      <div className="ai-widget-body">Богино асуултанд хариулъя.<br />Бүгдийг харахын тулд /chat хуудсыг нээнэ.</div>
      <div className="ai-widget-input">
        <input
          value={val}
          onChange={e => setVal(e.target.value)}
          placeholder="Асуулт..."
          onKeyDown={e => { if (e.key === 'Enter' && val.trim()) window.location.href = '/chat' }}
        />
        <button className="ai-widget-send" onClick={() => val.trim() && (window.location.href = '/chat')}>→</button>
      </div>
    </div>
  )
}
