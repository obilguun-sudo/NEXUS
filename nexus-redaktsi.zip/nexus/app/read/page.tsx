import Link from 'next/link'
import { DOCS } from '@/data/docs'
import AiWidget from '@/components/AiWidget'

function getBadgeClass(status: string) {
  if (status.includes('Нийтлэх')) return 'pub'
  if (status.includes('Засварт')) return 'draft'
  if (status.includes('Дотоод')) return 'internal'
  if (status.includes('Удирдлага')) return 'mgmt'
  return ''
}

export default function ReadPage() {
  const docs = DOCS.filter(d => d.read)

  return (
    <div className="content">
      <h1>Уншсан мэдээ</h1>
      <p className="page-desc">Редактор танилцсан мэдээ материал. Нийт <strong>{docs.length}</strong> мэдээ.</p>

      <div className="doc-table-wrap">
        <table className="doc-table">
          <thead>
            <tr>
              <th>№</th>
              <th>Огноо</th>
              <th>Мэдээний №</th>
              <th>Гарчиг</th>
              <th>Хаанаас</th>
              <th>Хавсралт</th>
              <th>Зэрэглэл</th>
            </tr>
          </thead>
          <tbody>
            {docs.map((doc, i) => (
              <tr key={doc.id}>
                <td className="doc-id">{i + 1}</td>
                <td className="doc-id" style={{ whiteSpace: 'nowrap' }}>{doc.date}</td>
                <td className="doc-id" style={{ whiteSpace: 'nowrap' }}>{doc.id}</td>
                <td><Link href={`/doc/${doc.id}`} className="doc-link">{doc.title}</Link></td>
                <td style={{ fontSize: 11, color: 'var(--t3)', maxWidth: 180 }}>{doc.source}</td>
                <td style={{ textAlign: 'center' }}>
                  {doc.attachments ? <span className="attach-icon"><i className="ti ti-paperclip" /> {doc.attachments.length}</span> : <span style={{ color: 'var(--t3)' }}>—</span>}
                </td>
                <td><span className={`badge ${getBadgeClass(doc.status)}`}>{doc.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <AiWidget />
    </div>
  )
}
