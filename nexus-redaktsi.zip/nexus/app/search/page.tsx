'use client'
import { useState } from 'react'
import Link from 'next/link'
import { DOCS, Doc } from '@/data/docs'
import AiWidget from '@/components/AiWidget'

function getBadgeClass(status: string) {
  if (status.includes('Нийтлэх')) return 'pub'
  if (status.includes('Засварт')) return 'draft'
  if (status.includes('Дотоод')) return 'internal'
  if (status.includes('Удирдлага')) return 'mgmt'
  return ''
}

export default function SearchPage() {
  const [text, setText] = useState('')
  const [sourceType, setSourceType] = useState('')
  const [category, setCategory] = useState('')
  const [status, setStatus] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [results, setResults] = useState<Doc[]>(DOCS)

  const runSearch = () => {
    let r = DOCS
    if (text) r = r.filter(d => d.title.toLowerCase().includes(text.toLowerCase()) || d.body.toLowerCase().includes(text.toLowerCase()) || d.source.toLowerCase().includes(text.toLowerCase()))
    if (sourceType) r = r.filter(d => d.sourceType === sourceType)
    if (category) r = r.filter(d => d.category === category)
    if (status) r = r.filter(d => d.status.includes(status))
    if (dateFrom) r = r.filter(d => d.date >= dateFrom)
    if (dateTo) r = r.filter(d => d.date <= dateTo)
    setResults(r)
  }

  const clear = () => { setText(''); setSourceType(''); setCategory(''); setStatus(''); setDateFrom(''); setDateTo(''); setResults(DOCS) }

  return (
    <div className="content">
      <h1>Дэлгэрэнгүй хайлт</h1>
      <p className="page-desc">Олон шүүлтүүрээр шүүх (огноо, эх сурвалж, ангилал, нууцлал, чөлөөт текст).</p>

      <div className="search-form">
        <div style={{ gridColumn: '1/-1' }}>
          <label>Чөлөөт текст</label>
          <input value={text} onChange={e => setText(e.target.value)} placeholder="Гарчиг, агуулга, эх сурвалжаар хайх..." onKeyDown={e => e.key === 'Enter' && runSearch()} />
        </div>
        <div>
          <label>Эх сурвалжийн төрөл</label>
          <select value={sourceType} onChange={e => setSourceType(e.target.value)}>
            <option value="">— Бүгд —</option>
            <option>Дотоод сурвалжлагч</option>
            <option>Гадаад агентлаг</option>
            <option>Эх сурвалжтай ярилцлага</option>
            <option>Тоон мониторинг / Fact-check</option>
          </select>
        </div>
        <div>
          <label>Ангилал</label>
          <select value={category} onChange={e => setCategory(e.target.value)}>
            <option value="">— Бүгд —</option>
            <option>Сэтгүүлзүйн судалгаа</option>
            <option>Медиа бизнес</option>
            <option>Худал мэдээлэл / Fact-check</option>
            <option>Хэвлэлийн эрх чөлөө</option>
          </select>
        </div>
        <div>
          <label>Нууцлал</label>
          <select value={status} onChange={e => setStatus(e.target.value)}>
            <option value="">— Бүгд —</option>
            <option value="Нийтлэх">Нийтлэх боломжтой</option>
            <option value="Засварт">Засварт</option>
            <option value="Дотоод">Дотоод хэрэглээ</option>
            <option value="Удирдлага">Удирдлагын зөвшөөрөл</option>
          </select>
        </div>
        <div>
          <label>Огнооноос</label>
          <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
        </div>
        <div>
          <label>Огноо хүртэл</label>
          <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} />
        </div>
        <div className="search-actions">
          <button className="btn primary" onClick={runSearch}>Хайх</button>
          <button className="btn" onClick={clear}>Цэвэрлэх</button>
        </div>
      </div>

      <div style={{ fontSize: 11, color: 'var(--t3)', marginBottom: 10 }}>{results.length} үр дүн</div>

      <div className="doc-table-wrap">
        <table className="doc-table">
          <thead>
            <tr>
              <th>№</th>
              <th>Огноо</th>
              <th>Мэдээний №</th>
              <th>Гарчиг</th>
              <th>Хаанаас</th>
              <th>Хавсралт</th>
              <th>Төрөл</th>
            </tr>
          </thead>
          <tbody>
            {results.map((doc, i) => (
              <tr key={doc.id}>
                <td className="doc-id">{i + 1}</td>
                <td className="doc-id" style={{ whiteSpace: 'nowrap' }}>{doc.date}</td>
                <td className="doc-id" style={{ whiteSpace: 'nowrap' }}>{doc.id}</td>
                <td><Link href={`/doc/${doc.id}`} className="doc-link">{doc.title}</Link></td>
                <td style={{ fontSize: 11, color: 'var(--t3)', maxWidth: 180 }}>{doc.source}</td>
                <td style={{ textAlign: 'center' }}>
                  {doc.attachments ? <span className="attach-icon"><i className="ti ti-paperclip" /> {doc.attachments.length}</span> : <span style={{ color: 'var(--t3)' }}>—</span>}
                </td>
                <td><span className={`badge ${getBadgeClass(doc.status)}`} style={{ fontSize: 10 }}>{doc.category}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <AiWidget />
    </div>
  )
}
