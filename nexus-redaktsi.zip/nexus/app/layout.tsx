'use client'
import './globals.css'
import { useState, useEffect, createContext, useContext } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const ThemeCtx = createContext<{ dark: boolean; toggle: () => void }>({ dark: false, toggle: () => {} })
export const useTheme = () => useContext(ThemeCtx)

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const [dark, setDark] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light')
  }, [dark])

  const nav = [
    { href: '/', label: 'Нүүр хуудас' },
    { href: '/inbox', label: 'Ирсэн мэдээ' },
    { href: '/read', label: 'Уншсан мэдээ' },
    { href: '/search', label: 'Дэлгэрэнгүй хайлт' },
  ]

  return (
    <html lang="mn" suppressHydrationWarning>
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/dist/tabler-icons.min.css" />
      </head>
      <body>
        <ThemeCtx.Provider value={{ dark, toggle: () => setDark(d => !d) }}>
          <div className="page-shell">
            <header className="topbar">
              <Link href="/" className="topbar-brand">
                NEXUS <span>//</span> NEWS DESK
              </Link>
              <span className="topbar-sub">ӨДРИЙН ТОЙМ — Редакцийн систем &nbsp;·&nbsp; Редактор: А.Дорж &nbsp;·&nbsp; UTC+08</span>
              <nav className="topbar-nav">
                {nav.map(n => (
                  <Link key={n.href} href={n.href} className={pathname === n.href ? 'active' : ''}>
                    {n.label}
                  </Link>
                ))}
              </nav>
              <div className="topbar-right">
                <span className="topbar-mode">Редакцийн горим</span>
                <Link href="/chat" className="topbar-ai-link">Редактор AI</Link>
                <button className="theme-toggle" onClick={() => setDark(d => !d)} aria-label="Загвар солих">
                  <i className={`ti ${dark ? 'ti-sun' : 'ti-moon'}`} />
                </button>
              </div>
            </header>
            {children}
          </div>
        </ThemeCtx.Provider>
      </body>
    </html>
  )
}
