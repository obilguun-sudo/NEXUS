// SERVER component — no 'use client' here.
// Next.js App Router REQUIRES the root layout to be a Server Component.
// Any client-side hooks (useState, usePathname, useEffect) must live
// in a child Client Component, never in this file.
import type { Metadata } from 'next'
import './globals.css'
import ClientShell from '@/components/ClientShell'

export const metadata: Metadata = {
  title: { default: 'NEXUS // NEWS DESK', template: '%s — NEXUS' },
  description: 'Редакцийн систем',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="mn" suppressHydrationWarning>
      <head>
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/dist/tabler-icons.min.css"
        />
      </head>
      <body>
        <ClientShell>{children}</ClientShell>
      </body>
    </html>
  )
}
