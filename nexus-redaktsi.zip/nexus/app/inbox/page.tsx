import Link from 'next/link'
import { DOCS } from '@/data/docs'
import AiWidget from '@/components/AiWidget'

function getBadgeClass(status: string) {
  if (status.includes('Нийтлэх')) return 'pub'
  if (status.includes('Засварт')) return 'draft'
  if (status.includes('Дотоод')) return 'internal'
  if (status.includes('Удирдлага')) return 'mgmt'
  return ''
}

export default function InboxPage() {
  const docs = DOCS.filter(d => !d.read)

  return (
    <div className="content">
      <h1>Ирсэн мэдээ</h1>
      <p className="page-desc">Редакцид шинээр ирсэн, редактор танилцаагүй мэдээ. Нийт <strong>{docs.length}</strong> мэдээ.</p>

      <div className="doc-table-wrap">
        <table className="doc-table">
          <thead>
            <tr>
              <th>№</th>
              <th>Огноо</th>
              <th>Мэдээний №</th>
              <th>Гарчиг</th>
              <th>Хаанаас</th>
              <th>Хавсралт</th>
              <th>Төрөл</th>
            </tr>
          </thead>
          <tbody>
            {docs.map((doc, i) => (
              <tr key={doc.id}>
                <td className="doc-id">{i + 1}</td>
                <td className="doc-id" style={{ whiteSpace: 'nowrap' }}>{doc.date}</td>
                <td className="doc-id" style={{ whiteSpace: 'nowrap' }}>{doc.id}</td>
                <td><Link href={`/doc/${doc.id}`} className="doc-link">{doc.title}</Link></td>
                <td style={{ fontSize: 11, color: 'var(--t3)', maxWidth: 180 }}>{doc.source}</td>
                <td style={{ textAlign: 'center' }}>
                  {doc.attachments ? <span className="attach-icon"><i className="ti ti-paperclip" /> {doc.attachments.length}</span> : <span style={{ color: 'var(--t3)' }}>—</span>}
                </td>
                <td><span className={`badge ${getBadgeClass(doc.status)}`} style={{ fontSize: 10 }}>{doc.category}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <AiWidget />
    </div>
  )
}
