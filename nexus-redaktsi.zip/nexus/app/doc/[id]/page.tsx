import { DOCS } from '@/data/docs'
import { notFound } from 'next/navigation'
import AiWidget from '@/components/AiWidget'
import Link from 'next/link'

function getBadgeClass(status: string) {
  if (status.includes('Нийтлэх')) return 'pub'
  if (status.includes('Засварт')) return 'draft'
  if (status.includes('Дотоод')) return 'internal'
  if (status.includes('Удирдлага')) return 'mgmt'
  return ''
}

export async function generateStaticParams() {
  return DOCS.map(d => ({ id: d.id }))
}

export default function DocPage({ params }: { params: { id: string } }) {
  const doc = DOCS.find(d => d.id === params.id)
  if (!doc) return notFound()

  return (
    <>
      <div style={{ background: 'var(--bg)', borderBottom: '1px solid var(--border)', padding: '0 16px', height: 36, display: 'flex', alignItems: 'center', gap: 12, fontSize: 11, color: 'var(--t2)', position: 'sticky', top: 38, zIndex: 90, overflowX: 'auto', flexShrink: 0 }}>
        <span style={{ fontSize: 10, fontWeight: 500, color: 'var(--t3)', border: '1px solid var(--border)', borderRadius: 2, padding: '1px 6px', background: 'var(--bg3)', marginRight: 4, whiteSpace: 'nowrap' }}>📝 NEXUS Editor — Document mode</span>
        {['Файл','Нүүр','Оруулах','Зохион байгуулалт','Шинжилгээ','Хяналт','Харах','Plugins'].map(m => (
          <span key={m} className="doc-ribbon-item">{m}</span>
        ))}
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6 }}>
          <span className="doc-id-badge">{doc.id}</span>
          <span style={{ color: 'var(--t3)', fontSize: 16, cursor: 'pointer' }}>🗒</span>
          <span style={{ color: 'var(--t3)', fontSize: 16, cursor: 'pointer' }}>💾</span>
          <span style={{ color: 'var(--t3)', fontSize: 16, cursor: 'pointer' }}>🖶</span>
        </div>
      </div>

      <div className="doc-shell">
        <div className="doc-body">
          <div style={{ fontSize: 10, color: 'var(--t3)', marginBottom: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <span>{doc.id}</span>
            <span className={`badge ${getBadgeClass(doc.status)}`}>{doc.status.toUpperCase()}</span>
            <span>{doc.sourceType.toUpperCase()}</span>
            <span>{doc.category}</span>
          </div>
          <h1>{doc.title}</h1>
          <div className="doc-meta">
            <span>{doc.source}</span>
            <span>·</span>
            <span>{doc.date}</span>
            <span>·</span>
            <span>Шалгагдсан байдал: {doc.status}</span>
          </div>
          <hr style={{ border: 'none', borderTop: '1px solid var(--border)', marginBottom: 20 }} />
          <div className="doc-content">{doc.body}</div>

          {doc.attachments && (
            <div className="doc-attachments">
              <h4>Хавсралт ({doc.attachments.length})</h4>
              {doc.attachments.map(a => (
                <div key={a.name} className="attach-item">
                  <i className="ti ti-paperclip" style={{ color: 'var(--gold)' }} />
                  <span style={{ color: 'var(--gold)' }}>{a.name}</span>
                  <span style={{ color: 'var(--t3)', fontSize: 10 }}>PDF · {a.size}</span>
                </div>
              ))}
            </div>
          )}

          <div style={{ marginTop: 24, fontSize: 10, color: 'var(--t3)', borderTop: '1px solid var(--border)', paddingTop: 10, display: 'flex', gap: 16 }}>
            <span>Хуудас 1 / 1</span>
            <span>{doc.body.split(' ').length} үг</span>
            <span>Монгол хэл</span>
          </div>
        </div>

        <aside className="doc-sidebar">
          <button className="ai-summarize-btn">
            <i className="ti ti-sparkles" />
            ⚡ AI: Хураангуйлах
          </button>

          <div style={{ fontSize: 10, color: 'var(--t3)', marginBottom: 10 }}>Шинжилгээ — Үг хэллэг</div>

          {doc.entities?.people && <>
            <h4>Хүмүүс</h4>
            <ul className="entity-list">
              {doc.entities.people.map(p => <li key={p} className="entity-item">{p}</li>)}
            </ul>
          </>}

          {doc.entities?.orgs && <>
            <h4>Байгууллага</h4>
            <ul className="entity-list">
              {doc.entities.orgs.map(o => <li key={o} className="entity-item">{o}</li>)}
            </ul>
          </>}

          {doc.entities?.geo && <>
            <h4>Газар зүй</h4>
            <ul className="entity-list">
              {doc.entities.geo.map(g => <li key={g} className="entity-item">{g}</li>)}
            </ul>
          </>}

          {doc.entities?.keywords && <>
            <h4>Түлхүүр үг</h4>
            <ul className="entity-list">
              {doc.entities.keywords.map(k => <li key={k} className="entity-item">{k}</li>)}
            </ul>
          </>}

          <div style={{ marginTop: 20 }}>
            <Link href="/chat" style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--gold)', textDecoration: 'none', border: '1px solid var(--border)', borderRadius: 2, padding: '6px 10px', transition: 'background .1s' }}>
              <i className="ti ti-message-2" />
              AI-д асуух
            </Link>
          </div>
        </aside>
      </div>
      <AiWidget />
    </>
  )
}
