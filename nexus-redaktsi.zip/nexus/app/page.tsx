import Link from 'next/link'
import { DOCS } from '@/data/docs'
import AiWidget from '@/components/AiWidget'

function getBadgeClass(status: string) {
  if (status.includes('Нийтлэх')) return 'pub'
  if (status.includes('Засварт')) return 'draft'
  if (status.includes('Дотоод')) return 'internal'
  if (status.includes('Удирдлага')) return 'mgmt'
  return ''
}

export default function HomePage() {
  const recent = DOCS.slice(0, 5)
  const total = DOCS.length
  const unread = DOCS.filter(d => !d.read).length
  const read = DOCS.filter(d => d.read).length
  const factcheck = DOCS.filter(d => d.category === 'Худал мэдээлэл / Fact-check').length

  const byCategory = [
    { label: 'Сэтгүүлзүйн судалгаа', count: DOCS.filter(d => d.category === 'Сэтгүүлзүйн судалгаа').length },
    { label: 'Медиа бизнес', count: DOCS.filter(d => d.category === 'Медиа бизнес').length },
    { label: 'Худал мэдээлэл / Fact-check', count: factcheck },
    { label: 'Хэвлэлийн эрх чөлөө', count: DOCS.filter(d => d.category === 'Хэвлэлийн эрх чөлөө').length },
  ]

  const bySource = [
    { label: 'Дотоод сурвалжлагч', count: DOCS.filter(d => d.sourceType === 'Дотоод сурвалжлагч').length },
    { label: 'Гадаад агентлаг', count: DOCS.filter(d => d.sourceType === 'Гадаад агентлаг').length },
    { label: 'Эх сурвалжтай ярилцлага', count: DOCS.filter(d => d.sourceType === 'Эх сурвалжтай ярилцлага').length },
    { label: 'Тоон мониторинг / Fact-check', count: DOCS.filter(d => d.sourceType === 'Тоон мониторинг / Fact-check').length },
  ]

  return (
    <div className="content">
      <h1>Нүүр хуудас</h1>
      <p className="page-desc">Редакцид ирсэн мэдээ материалын ерөнхий байдал.</p>

      <div className="stat-grid">
        <div className="stat-card"><div className="stat-num">{total}</div><div className="stat-label">Нийт мэдээ</div></div>
        <div className="stat-card"><div className="stat-num">{unread}</div><div className="stat-label">Ирсэн (уншаагүй)</div></div>
        <div className="stat-card"><div className="stat-num">{read}</div><div className="stat-label">Уншсан</div></div>
        <div className="stat-card"><div className="stat-num">{factcheck}</div><div className="stat-label">Fact-check идэвхтэй</div></div>
      </div>

      <div className="breakdown-grid">
        <div className="breakdown-card">
          <div className="breakdown-title">Ангилалаар</div>
          {byCategory.map(r => (
            <div className="breakdown-row" key={r.label}>
              <span className="breakdown-label">{r.label}</span>
              <span className="breakdown-val">{r.count}</span>
            </div>
          ))}
        </div>
        <div className="breakdown-card">
          <div className="breakdown-title">Эх сурвалжийн төрлөөр</div>
          {bySource.map(r => (
            <div className="breakdown-row" key={r.label}>
              <span className="breakdown-label">{r.label}</span>
              <span className="breakdown-val">{r.count}</span>
            </div>
          ))}
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <span style={{ fontSize: 10, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--t3)', fontWeight: 500 }}>Сүүлд орж ирсэн мэдээ</span>
        <Link href="/inbox" style={{ fontSize: 11, color: 'var(--gold)', textDecoration: 'none' }}>Бүгдийг харах →</Link>
      </div>
      <div className="doc-table-wrap">
        <table className="doc-table">
          <thead>
            <tr>
              <th>Огноо</th>
              <th>Мэдээний №</th>
              <th>Гарчиг</th>
              <th>Зэрэглэл</th>
              <th>Хаанаас</th>
            </tr>
          </thead>
          <tbody>
            {recent.map(doc => (
              <tr key={doc.id}>
                <td className="doc-id">{doc.date}</td>
                <td className="doc-id">{doc.id}</td>
                <td><Link href={`/doc/${doc.id}`} className="doc-link">{doc.title}</Link></td>
                <td><span className={`badge ${getBadgeClass(doc.status)}`}>{doc.status}</span></td>
                <td style={{ fontSize: 11, color: 'var(--t3)', maxWidth: 180, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{doc.source}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <AiWidget />
    </div>
  )
}
