# NEXUS // NEWS DESK — Редакцийн систем

Mongolian newsroom editorial management system with AI assistant (Редактор AI).

## Stack

- **Next.js 14** (App Router)
- **TypeScript**
- **Pure CSS** (no Tailwind, no component libraries)
- **Tabler Icons** (webfont, loaded from CDN)

## Pages

| Route | Description |
|-------|-------------|
| `/` | Dashboard — stats, breakdowns, recent docs |
| `/inbox` | Unread incoming news (108 items) |
| `/read` | Read/reviewed documents |
| `/search` | Advanced multi-filter search |
| `/doc/[id]` | Document viewer with entity panel + AI summarize |
| `/chat` | **Редактор AI** — redesigned chat interface |

## Features

### Редактор AI (`/chat`)
- Conversation history sidebar with **pin** and **group** support
- Collapsible sidebar toggle
- System banner: model info + data source notice
- **Perplexity-style sources**: source cards above the answer + inline `[NEX-XXX]` citation links within text
- Welcome screen with suggested prompts
- Composer: auto-resize textarea, attach + doc-search buttons
- Light/dark theme toggle (top-right of global nav)

### Document viewer (`/doc/[id]`)
- Word-like ribbon toolbar (decorative)
- Entity extraction panel (people, orgs, geo, keywords)
- Attachment list
- "AI-д асуух" link to /chat

### Search (`/search`)
- Client-side filtering: free text, source type, category, status, date range
- Live result count

## Setup

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Data

All documents live in `data/docs.ts`. Add new `Doc` objects to the `DOCS` array — they automatically appear across all pages (inbox, search, dashboard, doc routes).

## Deployment

Deploy to Vercel with zero config — push to GitHub and connect the repo.

```bash
git init
git add .
git commit -m "init: NEXUS newsroom system"
# connect to Vercel via dashboard or CLI
```

## Design decisions

- Monospace font throughout UI chrome (editorial/terminal feel)
- 1px sharp borders, 3px border-radius (not soft)
- `--gold: #c8a84b` as the primary accent
- CSS custom properties for full light/dark support
- No rounded cards, no shadows — flat utilitarian aesthetic
