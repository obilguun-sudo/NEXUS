'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const NAV = [
  { href: '/',       label: 'Нүүр хуудас' },
  { href: '/inbox',  label: 'Ирсэн мэдээ' },
  { href: '/read',   label: 'Уншсан мэдээ' },
  { href: '/search', label: 'Дэлгэрэнгүй хайлт' },
]

export default function ClientShell({ children }: { children: React.ReactNode }) {
  const [dark, setDark] = useState(false)
  const pathname = usePathname()

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light')
  }, [dark])

  return (
    <div className="page-shell">
      <header className="topbar">
        <Link href="/" className="topbar-brand">
          NEXUS <span>//</span> NEWS DESK
        </Link>
        <span className="topbar-sub">
          ӨДРИЙН ТОЙМ — Редакцийн систем &nbsp;·&nbsp; Редактор: А.Дорж &nbsp;·&nbsp; UTC+08
        </span>
        <nav className="topbar-nav">
          {NAV.map(n => (
            <Link key={n.href} href={n.href} className={pathname === n.href ? 'active' : ''}>
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="topbar-right">
          <span className="topbar-mode">Редакцийн горим</span>
          <Link href="/chat" className="topbar-ai-link">Редактор AI</Link>
          <button
            className="theme-toggle"
            onClick={() => setDark(d => !d)}
            aria-label="Загвар солих"
          >
            <i className={`ti ${dark ? 'ti-sun' : 'ti-moon'}`} />
          </button>
        </div>
      </header>
      {children}
    </div>
  )
}
